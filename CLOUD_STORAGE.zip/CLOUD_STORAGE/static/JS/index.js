var data = null;
$(document).ready(()=>{
  $.ajax({
    type : "GET",
    url : '/api?format=json',
    success:(e)=>{
      data = e;
      var to_put = '';
      for(var i in data){
        to_put += '<button onclick="edit(\''+data[i].FileName+'\')" class="file_name">'+data[i].FileName+'.py</button>';
        // console.log(data[i].FileName+'.py')
      }
      document.getElementById('names_of_files').innerHTML = to_put;
    }
  })
})
$(function () {
  $('#ide').keydown(function(e) {
    var keyCode = e.keyCode || e.which;
    if (keyCode == 9) {
      e.preventDefault();
      var start = $(this).get(0).selectionStart;
      var end = $(this).get(0).selectionEnd;
      var tmp =  document.getElementById('ide').value.substring(start,end - start + 1);
      spaces = "\t"
      $(this).val($(this).val().substring(0, start)
                  + spaces + $(this).val().substring(end));
      $(this).get(0).selectionStart =
      $(this).get(0).selectionEnd = start + 1;
    }
  });
});
function init(){
	document.getElementById('ide').style.width = parseInt(screen.width - 220)+"px"	;
}
function create_file_on_server() {
  if(document.getElementById('file_name').value.trim().length == 0)
    return;
  $.ajax({
    type:'POST',
    url : '/add',
    data:{
      'file_name':document.getElementById('file_name').value,
    },
    success:(e)=>{
      console.log(e);
      if(e == '-1'){
        alert('file already found');
        return;
      }
      edit(document.getElementById('file_name').value);
      location.reload();
    }
  });
}
function create_file(){
	document.getElementById('ide_container').style.display = 'none';
	document.getElementById('crt').style.display = 'block';
  
}
function rename() {
  if(document.getElementById('new_name').value.trim().length == 0){
    return;
  }
  $.ajax({
    type : 'GET',
    url : '/rename',
    data : {
      'old_name' : document.getElementById('title').innerHTML,
      'new_name' : document.getElementById('new_name').value,
    },
    success : ()=>{
      console.log('hello world');
      var to_put = '';
      document.getElementById('names_of_files').innerHTML = to_put;
      for(var i in data){
        if(data[i].FileName == document.getElementById('title').innerHTML){
          data[i].FileName = document.getElementById('new_name').value;
          document.getElementById('title').innerHTML = data[i].FileName;
        }
        to_put += '<button onclick="edit(\''+data[i].FileName+'\')" class="file_name">'+data[i].FileName+'.py</button>';
       
      }
      document.getElementById('names_of_files').innerHTML = to_put;
    }
  })
}
function save_data_to_server() {
  $.ajax({
    type : 'POST',
    url  : '/save_file',
    data : {
        'data' : document.getElementById('ide').value,
        'file_name' : document.getElementById('title').innerHTML,
    },
    success:(e)=>{
      for(var i in data){
        if(data[i].FileName === document.getElementById('title').innerHTML){
          data[i].Content = document.getElementById('ide').value;
          break;
        }
      }
    },
    error:(e)=>{
      
      console.log('error : ' + e);
    }
  });
}
function edit(name_of_file){
	document.getElementById("ide_container").style.display = "block";
	document.getElementById('crt').style.display = 'none';
	document.getElementById('title').innerHTML = name_of_file;
  for(var i in data){
    if(data[i].FileName == name_of_file){
      document.getElementById('ide').value = data[i].Content;
    }
  }
}
function delete_file_on_server(){
  $.ajax({
    type : 'POST',
    url : '/delete',
    data : {
      'file_name' : document.getElementById('title').innerHTML,
    },
    success : (response)=>{
      var delete_index = -1;
      for(var i in data){
        if(data[i].FileName === document.getElementById('title').innerHTML){
          delete_index = i;
          data.splice(delete_index,1);
          break;
        }
      }
      location.reload();
    }
  })
}
function run_file_on_server(){
  $.ajax({
    type : 'POST',
    url  : '/runcode',
    data : {
      'code' : document.getElementById('ide').value,
      'input' : document.getElementById('inp').value,
    },
    success : (e)=>{
      document.getElementById('op').innerHTML = e.output;
      console.log(e.output);
    }
  });
}