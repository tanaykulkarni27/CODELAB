from rest_framework.views import APIView
from rest_framework import serializers
from rest_framework.response import Response
from .models import File
from django.shortcuts import get_object_or_404,HttpResponse
class APIModel(serializers.ModelSerializer):
	class Meta:
		model = File
		fields = ['Email','FileName','Content']	
class API(APIView):
	def get(self,req):
		email = req.user.email;
		all_rows = File.objects.all().filter(Email = email);
		return Response(APIModel(all_rows,many = True).data)
def save(req):
	content = req.POST.get('data');
	email = req.user.email;
	File_Name = req.POST.get('file_name');
	print('DBG : '+content);
	print('DBG : '+File_Name);
	row = get_object_or_404(File,Email = email,FileName = File_Name)
	if row != None:		
		row.Content = content;
		row.save();
		return HttpResponse("SUCCESS")
	assert False,"Row not found error"
def delete_file(req):
	email = req.user.email
	file_name = req.POST.get('file_name')
	row = get_object_or_404(File,Email = email,FileName = file_name)
	if row != None:
		row.delete();
	return HttpResponse('hello world')

def updt_name(req):
	old_name = req.GET.get('old_name')
	new_name = req.GET.get('new_name')
	row = get_object_or_404(File,Email = req.user.email,FileName = old_name)
	if row != None:
		row.FileName = new_name;
		row.save(); 
	return HttpResponse('hello world')