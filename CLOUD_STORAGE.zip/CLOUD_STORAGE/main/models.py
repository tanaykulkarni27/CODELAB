from django.db import models
class File(models.Model):
	Email = models.TextField(unique=False,blank =False)
	FileName = models.TextField(unique=True,blank = False)
	Content = models.TextField(default = '', unique=False,blank = True)