from django.shortcuts import render,redirect,HttpResponse,get_object_or_404
from django.http import JsonResponse
from pathlib import Path
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
import os
import time
from .models import File
import subprocess
BASE_DIR = Path(__file__).resolve().parent.parent
def __RunFileHelper (email):
	cmd = 'python "' + str(BASE_DIR) + '\\data\\' + email +'\\tmp.py" < ';
	cmd += '"' + str(BASE_DIR) + '\\data\\' + email + '\\inputf.in"'
	# cmd += '"' + str(BASE_DIR) + '\\data\\' + email + '\\output.out" '
	print('\nDEBUG : ' + cmd)
	print()
	x = subprocess.Popen(cmd,shell= True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
	time.sleep(2);
	output = x.communicate()[0]
	if x.returncode != 0:
		with open(str(BASE_DIR) + '\\data\\' + email + '\\output.out','w+') as f:
			f.write('runtime error');
	else:
		output = output.decode('utf-8');
		print('\nDEBUG : ' + output)
		print()
		with open(str(BASE_DIR) + '\\data\\' + email + '\\output.out','w+') as f:
			f.write(output)
def RunFile(req):
	code = req.POST.get('code')
	input_stream = req.POST.get('input')
	email = req.user.email
	data = dict()
	with open(str(BASE_DIR) + '\\data\\' + email +'\\tmp.py','w') as f:
		f.write(code)
	with open(str(BASE_DIR) + '\\data\\' + email +'\\inputf.in','w') as f:
		f.write(input_stream)
	__RunFileHelper(email);
	with open(str(BASE_DIR) + '\\data\\' + email +'\\output.out','r') as f:
		data['output'] = f.read().replace('\n','<br>')
	return JsonResponse(data)
def create_file(req):
	if req.method.lower() == "post":
		file_name = req.POST.get('file_name');
		email = req.user.email
		if File.objects.all().filter(Email = email,FileName = file_name):
			return HttpResponse('-1');
		x = File(FileName = file_name,Email = email,Content = '');
		x.save();
		return HttpResponse('1');
	assert False,"Post Method Required Found Get";
def home(req):
	if req.user.is_authenticated == False:
		return redirect('/login')
	# os.system('mkdir "{}\\data\\{}"'.format(BASE_DIR,req.user.email))
	# with open('{}\\data\\{}\\input.in'.format(BASE_DIR,req.user.email),'w+') as f:
	# 	f.write('');
	# with open('{}\\data\\{}\\output.out'.format(BASE_DIR,req.user.email),'w+') as f:
	# 	f.write('');
	# with open('{}\\data\\{}\\tmp.py'.format(BASE_DIR,req.user.email),'w+') as f:
	# 	f.write('');
	return render(req,'index.html');
def getout(req):
	logout(req);
	return redirect('http://localhost:8000');
def getin(req):
	user_name = req.POST.get('uname');
	pwd = req.POST.get('pwd')
	x = authenticate(username = user_name,password = pwd)
	if x != None:
		login(req,x);
		return redirect('http://localhost:8000')
	return render(req,'user.html')
'''
Logic
	Table File
		Assigned_Email : EmailField
		FileCount  : IntegerField
		FileName : TextField
		FileContainer : TextField

    <button class="file_name" align="center" onclick="edit('Name1')">Name 1</button>

'''